#!/bin/bash

./config.sh
. /functions.sh


echo"
HOST: $HOST
PORT: $PORT
USER: $USER
PASS: $PASS
DN: $DB
user: $user
pass: $pass
username: $username
" > TMPTXT

user_pass=$(mysql -h$HOST -P$PORT -u$USER -p$PASS $DB -sN -e "SELECT user_pass FROM user WHERE 
user_id = '$username' AND user_enable=1 AND (TO_DAYS(now()) >= TO_DAYS(user_start_date) 
OR user_start_date IS NULL) AND (TO_DAYS(now()) <= TO_DAYS(user_end_date) OR user_end_date IS NULL)")

echo "
user_pass=$(mysql -h$HOST -P$PORT -u$USER -p$PASS $DB -sN -e "SELECT user_pass FROM user WHERE 
user_id = '$username' AND user_enable=1 AND (TO_DAYS(now()) >= TO_DAYS(user_start_date) 
OR user_start_date IS NULL) AND (TO_DAYS(now()) <= TO_DAYS(user_end_date) OR user_end_date IS NULL)")
">TMPTXT2

# Check the user
if [ "$user_pass" == '' ]; then
  echo "$username: bad account."
  exit 1
fi

mysql -hlocalhost -P3306 -uopenvpn -policout openvpn-admin -sN -e 'SELECT user_pass FROM user WHERE
user_id = 'tutu' AND user_enable=1 AND (TO_DAYS(now()) >= TO_DAYS(user_start_date)
OR user_start_date IS NULL) AND (TO_DAYS(now()) <= TO_DAYS(user_end_date) OR user_end_date IS NULL)'

userpass=$(mysql -hlocalhost -P3306 -uopenvpn -policout openvpn-admin -sN -e "SELECT user_pass FROM user WHERE user_id = 'tutu' AND user_enable=1 AND (TO_DAYS(now()) >= TO_DAYS(user_start_date) OR user_start_date IS NULL) AND (TO_DAYS(now()) <= TO_DAYS(user_end_date) OR user_end_date IS NULL)")
mysql -hlocalhost -P3306 -uopenvpn -policout openvpn-admin -sN -e \
"SELECT user_pass FROM user WHERE user_id = 'tutu' AND user_enable=1 \
AND (TO_DAYS(now()) >= TO_DAYS(user_start_date) OR user_start_date IS NULL) \
AND (TO_DAYS(now()) <= TO_DAYS(user_end_date) OR user_end_date IS NULL)"


